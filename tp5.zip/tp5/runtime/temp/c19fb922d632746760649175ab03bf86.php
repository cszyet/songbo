<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:69:"D:\website\tp5\public/../application/index\view\index\adult_exam.html";i:1495377858;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>上海嵩博进修学院——上海成人高考｜上海成考本科｜上海夜大本科｜上海成人教育</title>
    <meta name="keywords" content="成人高考,成人本考,夜大本科,成考,夜大,上海嵩博进修学院" />
    <meta name="description" content="嵩博进修学院是成人高考合作院校，常年开设业余制周末成考专本科课程。无学历、无年龄限制，每周一天轻松取得学历证书。咨询热线：400-820-1728">
    <link rel="stylesheet" href="/static/css/base_adult.css"/>
    <link rel="stylesheet" href="/static/css/accordion.css"/>
    <script src="/static/js/jquery-1.11.1.min.js"></script>
    <script src="/static/js/aaAccordion.class.js"></script>
    <script type="text/javascript">
        jQuery(document).ready(function () {
            jQuery('#firstAcc').aaAccordion({
                animationSpeed: 350,
                easing: 'easeOutQuad',
                startWidth: 500,
                margin: 0,
                firstOpen: 1,
                startAfter: 1300,
                itemWidth: 500,
                itemHeight: 500,
                hoverGray: true,
                keyBrowse: true,
                pauseOnHover: false,
                autoplay: true, // autoplay easing
                autoplaySpeed: 3500 // autoplay interval speed
            });
        });
    </script>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<body>
<div class="nav" id="nav">
    <div class="w1000">
        <div class="logo"><img src="/static/images/logo.png" alt=""/></div>
        <div class="nav_bar">
            <ul>
                <li><a href="/index.html">学历首页</a></li>
                <li><a href="/diy_exam.html">成人自考</a></li>
                <li><a class="nav_bar_active" href="#">成人高考</a></li>
                <li><a href="javascript:void(0);" onclick="open_qq()">远程教育</a></li>
                <li><a href="javascript:void(0);" onclick="open_qq()">函授学历</a></li>
                <li><a href="javascript:void(0);" onclick="open_qq()">合作院校</a></li>
                <li><a href="javascript:void(0);" onclick="open_qq()">热门专业</a></li>
            </ul>
        </div>
    </div>
</div>
<div class="banner"><img src="/static/images/banner_adult.jpg"  style="max-width:1400px;"></div>
<div class="w1">
    <div class="w980">
        <div><img src="/static/images/w1_adult.jpg" alt=""/></div>
        <table>
            <tr>
                <td><a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/w1_1.jpg" alt=""/></a></td>
                <td><a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/w1_2.jpg" alt=""/></a></td>
                <td><a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/w1_3.jpg" alt=""/></a></td>
            </tr>
        </table>
        <div><img src="/static/images/w1_t.jpg" alt=""/></div>
        <div class="btn"><a href="javascript:void(0);" onclick="open_qq()">点击申请免试入学</a></div>
    </div>
</div>
<div class="aaAccordion" id="firstAcc">
    <div class="content">
        <ul>
            <li class="">
                <div class="full-img">
                    <a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/c1.jpg" alt="img title" border="0" id="cvs-img-0" style="display: block;"></a> </div>
                <div class="caption">
                    <h1>上海财经大学</h1>

                    <p>深厚的财经类办学底蕴<br>培养具备扎实的会计学基础理论、专门知识和基本技能<br>提供成为财务高级管理人才的机会</p>
                    <a onClick="open_qq()" class="go-btn">go button</a>
                </div>
            </li>
            <li class="">
                <div class="full-img">
                    <a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/c2.jpg" alt="img title" width="500" height="500" border="0"></a> </div>
                <div class="caption">
                    <h1>上海师范大学</h1>

                    <p>毕业颁发本科学历证书，国家认可，学信网可查<br>取证时间3年，可以根据个人需求自主制定学习进度，<br>允许缩短或延后学习年限</p>
                    <a class="go-btn">go button</a>
                </div>
            </li>

            <li class="">
                <div class="full-img">
                    <a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/c4.jpg" alt="img title" border="0"></a> </div>
                <div class="caption">
                    <h1>上海第二工业大学</h1>

                    <p>两年学习半年毕业设计,轻松取证<br>毕业颁发本科学历证书，国家认可，学信网可查<br>全部课程正常通过即可申请学士学位</p>
                    <a onClick="open_qq()" class="go-btn">go button</a>
                </div>
            </li>
            <li class="on">
                <div class="full-img">
                    <a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/c5.jpg" alt="img title" width="500" height="500" border="0"></a> </div>
                <div class="caption">
                    <h1>上海金融学院</h1>

                    <p>名牌大学，未来金融家的摇篮<br>培养具有现代金融、管理、法律、信息技术等方面知识<br>的应用型专门人才</p>
                    <a class="go-btn">go button</a>
                </div>
            </li>
        </ul>
    </div>
</div>
<div class="w2">
    <div class="w980">
        <div><img src="/static/images/w2_adult.jpg" alt=""/></div>
        <div class="flow">
            <div class="f_t">
                <ul>
                    <li class="fi f_t_i  f_t_1 f_t_1_h "></li>
                    <li class="fi f_t_i  f_t_2 "></li>
                    <li class="fi f_t_i f_t_3 "></li>
                    <li class="fi f_t_i f_t_4 "></li>
                    <li class="fi f_t_i f_t_5 "></li>
                </ul>
            </div>
            <div class="f_m">
                <ul>
                    <li><a href="" class="fi f_m_i f_m_i_h"></a></li>
                    <li><a href="" class="fi f_m_i "></a></li>
                    <li><a href="" class="fi f_m_i "></a></li>
                    <li><a href="" class="fi f_m_i "></a></li>
                    <li><a href="" class="fi f_m_i "></a></li>
                </ul>
            </div>
            <div class="f_b">
                <div class="f_b_con">资深学历教育顾问为学员量身选择学校、专业，全程解读成考信息及指导报名流程。</div>
                <div class="f_b_btn"><a href="javascript:void(0);" onclick="open_qq()">了解详情</a></div>
                <div class="triangle tr1"></div>
            </div>
        </div>

        <div class="w2_branch">
            <div><img src="/static/images/w2_1_adult.jpg" alt=""/></div>
        </div>
    </div>
    <div class="w1000">
        <ul>
            <li style="margin:0 8px 0 0"><a href="javascript:void(0);" onclick="open_qq()">黄浦区</a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()">徐汇区</a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()">长宁区</a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()">静安区</a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()">普陀区</a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()">闸北区</a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()">虹口区</a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()">杨浦区</a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()">宝山区</a></li>
        </ul>
        <ul>
            <li style="visibility: hidden;margin:0 8px 0 0;"><a href="javascript:void(0);" onclick="open_qq()"></a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()">徐汇区</a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()">嘉定区</a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()">浦东新区</a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()">松江区</a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()">金山区</a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()">青浦区</a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()">奉贤区</a></li>
            <li style="visibility: hidden"><a href="javascript:void(0);" onclick="open_qq()"></a></li>
        </ul>
    </div>
</div>
<div class="w3">
    <div class="w980">
        <div><img src="/static/images/w3_adult.jpg" alt=""/></div>
    </div>
    <div class="w1253">
        <table>
            <tr>
                <td><a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/w3_1.jpg" alt=""/></a></td>
                <td><a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/w3_2.jpg" alt=""/></a></td>
                <td><a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/w3_3.jpg" alt=""/></a></td>
            </tr>
            <tr>
                <td><a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/w3_4.jpg" alt=""/></a></td>
                <td><a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/w3_5.jpg" alt=""/></a></td>
                <td><a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/w3_6.jpg" alt=""/></a></td>
            </tr>
        </table>
    </div>
</div>
<div class="w4">
    <div class="w980">
        <img src="/static/images/w4_adult.jpg" alt=""/>

        <div>
            <ul>
                <li><a href="javascript:void(0);" onclick="open_qq()" class="w4_ig i1"></a></li>
                <li><a href="javascript:void(0);" onclick="open_qq()" class="w4_ig i2"></a></li>
                <li><a href="javascript:void(0);" onclick="open_qq()" class="w4_ig i3"></a></li>
                <li><a href="javascript:void(0);" onclick="open_qq()" class="w4_ig i4"></a></li>

            </ul>
        </div>
    </div>
</div>
<div class="w5">
    <div class="w980">
        <img src="/static/images/w5_adult.jpg" alt=""/>
        <ul>
            <li><a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/w5_1.jpg" alt=""/></a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/w5_2.jpg" alt=""/></a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/w5_3.jpg" alt=""/></a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/w5_4.jpg" alt=""/></a></li>
        </ul>
        <div class="btn_2"><span><a href="javascript:void(0);" onclick="open_qq()">我要报读成教课程</a></span><span>TEL:17898837879</span></div>
    </div>
</div>
<div class="w6">
    <div class="w980">
        <img src="/static/images/w6_adult.jpg" alt=""/>
        <ul>
            <li><a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/w6_1.jpg" alt=""/></a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/w6_2.jpg" alt=""/></a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/w6_3.jpg" alt=""/></a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/w6_4.jpg" alt=""/></a></li>
        </ul>
        <div class="btn_2"><span><a href="javascript:void(0);" onclick="open_qq()">我要报读成教课程</a></span><span>TEL:17898837879</span></div>
    </div>
</div>
<div class="w7">
    <div class="w980">
        <span class="w7_btn w7_b1"><a href="javascript:void(0);" onclick="open_qq()">查看六大特招课程</a></span>
        <span class="w7_btn w7_b2"><a href="javascript:void(0);" onclick="open_qq()">了解高校独家内训</a></span>
        <span class="w7_btn w7_b3"><a href="javascript:void(0);" onclick="open_qq()">预约考前命题破解课</a></span>
        <span class="w7_btn w7_b4"><a href="javascript:void(0);" onclick="open_qq()">查看高校名师预测</a></span>
    </div>
</div>
<div class="w8">
    <div class="w980">
        <span class="w8_btn w8_b1"><a href="javascript:void(0);" onclick="open_qq()">点击了解</a></span>
        <span class="w8_btn w8_b2"><a href="javascript:void(0);" onclick="open_qq()">点击了解</a></span>
        <span class="w8_btn w8_b3"><a href="javascript:void(0);" onclick="open_qq()">点击了解</a></span>
        <span class="w8_btn w8_b4"><a href="javascript:void(0);" onclick="open_qq()">点击了解</a></span>
    </div>
</div>
<div class="w9">
    <img src="/static/images/w9_adult.jpg" alt=""/>

    <div class="btn_2"><span><a href="javascript:void(0);" onclick="open_qq()">我要报读成教课程</a></span><span>TEL:17898837879</span></div>
</div>
<div class="wrap wrap_02">
    <div class="contain foot">
        <div class="foot_code">
            <div><img src="/static/images/code_01.png"></div>
            <div><img src="/static/images/code_02.png"></div></div>
        <dl class="clearfix">

            <dd id="footHelp">
                <strong><i></i><a href="javascript:void(0);" onclick="open_qq()">客服中心</a></strong>
                <span class="clearfix"><a href="javascript:void(0);" onclick="open_qq()"><em>17898837879</em>（免长途费）</a></span>
                <span class="clearfix"><a href="javascript:void(0);" onclick="open_qq()"><div class="fIcon_01" style="background-position: -5px -62px"></div>邮箱：Service@neworldonline.org</a></span>
                <span class="clearfix"><a href="http://weibo.com/neworldonline" target="_blank"><div class="fIcon_02" style="background-position: -5px -9px;"></div>新浪微博：weibo.com/neworldonline</a></span>
                <span class="clearfix"><a href="javascript:void(0);" onclick="open_qq()"><div class="fIcon_04" style="background-position: -5px -35px;"></div>在线客服（每日9:00-24:00）</a></span>
            </dd>
            <dd>
                <strong><a href="###" target="_blank">关于课程</a></strong>
                <span><a href="###" target="_blank">成人自考</a></span>
                <span><a href="###" target="_blank">成人高考</a></span>
                <span><a href="###" target="_blank">远程教育</a></span>
                <span><a href="##" target="_blank">网络教育</a></span>
            </dd>
            <dd>
                <strong style="visibility: hidden" ><a href="javascript:void(0);" onclick="open_qq()">关于课程</a></strong>
                <span><a href="#" target="_blank">日语培训</a></span>
                <span><a href="#" target="_blank">英语培训</a></span>
                <span><a href="#" target="_blank">法语培训</a></span>
                <span><a href="#" target="_blank">德语培训</a></span>
            </dd>
            <dd>
                <strong><a href="javascript:void(0);" onclick="open_qq()">嵩博集团</a></strong>
                <span><a href="javascript:void(0);" onclick="open_qq()">关于我们</a></span>
                <span><a href="javascript:void(0);" onclick="open_qq()">学校荣誉</a></span>
                <span><a href="javascript:void(0);" onclick="open_qq()">联系我们</a></span>
                <span><a href="javascript:void(0);" onclick="open_qq()">友情链接</a></span>
                <span><a href="javascript:void(0);" onclick="open_qq()">招聘贤才</a></span>
            </dd>
        </dl>
    </div>
</div>
Copyright @2016 上海嵩博教育科技有限公司 版权所有All rights reserved 沪ICP备08018177号
<div id="doyoo_panel" class="doyoo_pan_icon" style="position: fixed; top: 150px; right: 5px; width: 125px; height: 356px;">
    <div class="doyoo_pan_icon_inner" id="looyu_dom_0" style="width: 125px; float: right; background-image: url(&quot;/static/images/zx1.png&quot;);">
        <a href="javascript:;" id="looyu_dom_1" style="display:block;width:100%;height:100%;">&nbsp;</a>
    </div>
</div>
<link rel="stylesheet" type="text/css" href="/static/css/oms.css">
<script>
    var arr = ["资深学历教育顾问为学员量身选择学校、专业，全程解读成考信息及指导报名流程。", "各大招生院校专家团队亲临授课，一二轮系统全面复习。一流的软硬件设施，全城最佳成考学习点。", "考前心理老师辅导，轻松备考、沉着应考。组织学员参加成人高考。", "新生入学典礼，圆那个曾经无数个憧憬的大学梦。", "参加各学期组织的期末考试，检验学习成果的最佳时刻。等待的是收获辛苦耕耘的果实。"];
    $(".f_m_i").on("click", function (x) {
        x.preventDefault();
        var _index = $(".f_m_i").index(this) + 1;
        var index = $(".f_m_i").index(this);
        console.log(_index);
        $(".f_m_i").removeClass("f_m_i_h");
        $(this).addClass("f_m_i_h");
        $(".triangle")[0].className = "triangle";
        $(".triangle").addClass('tr' + _index);
        $(".f_t_i").each(function (index) {
            var id = index + 1;
            $(".f_t_i").removeClass('f_t_' + id + "_h");
        });
        $(".f_t_" + _index).addClass('f_t_' + _index + "_h");
        $(".f_b_con").html(arr[index]);
    });
    $(".f_t_i").on("click",function(x){
        x.preventDefault();
        var _index = $(".f_t_i").index(this) + 1;
        var index = $(".f_t_i").index(this);
        console.log(_index);
        $(".f_t_i").each(function (index) {
            var id = index + 1;
            $(".f_t_i").removeClass('f_t_' + id + "_h");
        });
        $(".f_t_" + _index).addClass('f_t_' + _index + "_h");
        $(".f_m_i").removeClass("f_m_i_h");
        $(".f_m_i").eq(index).addClass('f_m_i_h');
        $(".triangle")[0].className = "triangle";
        $(".triangle").addClass('tr' + _index);
        $(".f_b_con").html(arr[index]);
    })
</script>
<script>
    var title =document.getElementById("nav");
    window.onscroll = function(){
        var scrollTop = document.documentElement.scrollTop ||document.body.scrollTop;
        if(scrollTop>45){
            title.style.opacity="0.8";
        }else{
            title.style.opacity="1";
        }

    }
</script>
<script src="/static/js/common.js"></script>
</body>
</html>