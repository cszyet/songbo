function open_qq ()
{
    window.location.href = "tencent://message/?uin=1019980842&Site=b5m&Menu=yes";
    return false;
}