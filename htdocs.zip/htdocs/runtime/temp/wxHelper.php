<?php

namespace app\helper;
use \Exception;

class wxHelper
{
    public $appid;
    private $appsecret;
    public $access_token;
    public $api_ticket;

    public function __construct() {

        $this->appid = 'wx68df00e7432ff4f5';
        $this->appsecret = '79b14c18aa2adcae1a7f6a71cf69eecc';
        $this->get_access_token();

    }


    /**
     * 通过code获取授权信息
     * @param $code
     * @return mixed
     */
    public function getAuthorization($code){
        $url = "https://api.weixin.qq.com/sns/oauth2/access_token?appid=".$this->appid."&secret=".$this->appsecret."&code=".$code."&grant_type=authorization_code";
        $res = $this->https_request($url);
        return json_decode($res, true);
    }

    /**
     * 微信授权登录
     * @param $callbackurl
     */
    public function autorize ($callbackurl)
    {
        $url = "https://open.weixin.qq.com/connect/oauth2/authorize?appid=".$this->appid."&redirect_uri=".urlencode($callbackurl)."&response_type=code&scope=snsapi_userinfo&state=55haitao#wechat_redirect";
        header("Location: $url");//跳转授权页
    }


    public function get_access_token() {
        $model = db("wx_tokens");
        $now = time();
        $this->access_token = file_get_contents("/opt/lampp/htdocs/runtime/temp/token.txt");

        if (!$this->access_token) {
            //获取新的
            $info = http_request('https://api.weixin.qq.com/cgi-bin/token?grant_type=client_credential&appid='.$this->appid.'&secret='.$this->appsecret);
            $info = json_decode($info, true);


            if (isset ($info['access_token']) && $info['access_token']) {
                file_put_contents("/opt/lampp/htdocs/runtime/temp/token.txt",$info['access_token']);
                $this->access_token = $info['access_token'];
            }
        }

        return $this->access_token;
    }

    public function get_api_ticket() {

        $now = time();
        $model = db("wx_tokens");
        $this->api_ticket = $model->where(['type' => 2, 'expires_time' => ['gt', $now]])->value('kvalue');

        if (!$this->api_ticket) {
            $info = http_request('https://api.weixin.qq.com/cgi-bin/ticket/getticket?access_token='.$this->access_token.'&type=jsapi');

            $info = json_decode($info, true);

            if ($info['errcode'] == 0 && $info['ticket']) {
                $save_data = [
                    'kvalue' => $info['ticket'],
                    'expires_time' => $now + $info['expires_in'] - 60,
                    'type' => 2,
                ];

                db("wx_tokens")->insert($save_data);
                $this->api_ticket = $info['ticket'];
            }
        }

        return $this->api_ticket;
    }

    /**
     * 产生随机字符串
     * @param int $length
     * @param string $str
     * @return string
     */
    public function createNoncestr($length = 32, $str = "")
    {
        $chars = "abcdefghijklmnopqrstuvwxyz0123456789";
        for ($i = 0; $i < $length; $i++) {
            $str .= substr($chars, mt_rand(0, strlen($chars) - 1), 1);
        }
        return $str;
    }

    /**
     * 获取签名
     * @param array $arrdata 签名数组
     * @param string $method 签名方法
     * @return bool|string 签名值
     */
    public function getSignature($arrdata, $method = "sha1")
    {
        if (!function_exists($method)) {
            return false;
        }
        ksort($arrdata);
        $params = array();
        foreach ($arrdata as $key => $value) {
            $params[] = "{$key}={$value}";
        }
        return $method(join('&', $params));
    }

    /**
     * 网页请求
     * @param $url
     * @param null $data
     * @return mixed
     */
    private function https_request($url, $data = null)
    {
        $curl = curl_init();
        curl_setopt($curl, CURLOPT_URL, $url);
        curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, FALSE);
        curl_setopt($curl, CURLOPT_SSL_VERIFYHOST, FALSE);
        if (!empty($data)){
            curl_setopt($curl, CURLOPT_POST, 1);
            curl_setopt($curl, CURLOPT_POSTFIELDS, $data);
        }
        curl_setopt($curl, CURLOPT_RETURNTRANSFER, 1);
        $output = curl_exec($curl);
        curl_close($curl);
        return $output;
    }
}