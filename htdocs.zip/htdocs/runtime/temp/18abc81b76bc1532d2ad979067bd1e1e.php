<?php if (!defined('THINK_PATH')) exit(); /*a:1:{s:67:"/opt/lampp/htdocs/public/../application/index/view/index/index.html";i:1495452118;}*/ ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <title>上海嵩博进修学院——上海本科学历｜上海专科学历｜上海自考本科｜上海成人高考｜上海网络本科</title>
    <meta property="wb:webmaster" content="dd7f3dbf2f910e9e" />
    <meta name="keywords" content="本科学历,专科学历,自考本科,网络本科,成人高考,上海嵩博学历" />
    <meta name="description" content="嵩博进修学院是自考、成考、网络指定助学单位，常年开设业余制自考、成考、网络专本科课程。无学历、无年龄限制，考试院“0利率”助学贷款，轻松取得学历证书。咨询热线：400-820-1728">
    <link rel="stylesheet" href="/static/css/style.css"/>
    <link rel="stylesheet" type="text/css" href="/static/css/carousel.css"/>
    <script type="text/javascript">
        function CheckForm(){
            var name=document.getElementById("Orders_Name");
            var tel=document.getElementById("Orders_Tel");
            //var courses=document.getElementById("Courses_id");
            var RegEmpty=/^\s*$/;  //匹配所有空字符
            var RegMobile=/^1[3458]\d{9}$/; //匹配当前国内手机号
            var RegUsername=/[a-zA-Z\u4E00-\u9FA5]+/; //匹配所有汉字和英文字母

            if(RegEmpty.test(name.value)){
                alert('请填写姓名');
                name.focus();
                return false;
            }else if(RegUsername.test(name.value.replace(/(^\s*)|(\s*$)/g,""))==false){ //去掉字符串两侧空字符，并验证是否是汉字或者字母
                alert('用户名必须为汉字或者英文字母！')
                name.focus();
                return false;
            }
            if(RegEmpty.test(tel.value)){
                alert('请填写手机号');
                tel.focus();
                return false;
            }else if(RegMobile.test(tel.value.replace(/(^\s*)|(\s*$)/g,""))==false){ //去掉字符串两侧空字符，并验证是否是11为手机号
                alert('请输入11为手机号码！');
                tel.focus();
                return false;
            }
            document.getElementById('btn_submit').disabled='disabled';
            return true;
        }
    </script>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
</head>
<style>
    .SlideTriggers{
        display: none;
    }
</style>
<body>
<div class="nav" id="nav">
    <div class="w1000">
        <div class="logo"><a href="/index.html"><img src="/static/images/logo.png" alt="嵩博进修学院"/></a></div>
        <div class="nav_bar">
            <ul>
                <li><a class="nav_bar_active" href="/index.html">学历首页</a></li>
                <li><a href="/diy_exam.html">成人自考</a></li>
                <li><a href="/adult_exam.html">成人高考</a></li>
                <li><a href="javascript:void(0);" onclick="open_qq()">远程教育</a></li>
                <li><a href="javascript:void(0);" onclick="open_qq()">函授学历</a></li>
                <li><a href="javascript:void(0);" onclick="open_qq()">合作院校</a></li>
                <li><a href="javascript:void(0);" onclick="open_qq()">热门专业</a></li>
            </ul>
        </div>
    </div>
</div>
<div id="banner" class="carousel slide" style="width: 100%;overflow: hidden;">
    <!-- 轮播（Carousel）指标 -->
    <ol class="carousel-indicators">
        <li data-target="#banner" data-slide-to="0" class="active slide-one"></li>
        <li data-target="#banner" data-slide-to="1" class="slide-two"></li>
        <li data-target="#banner" data-slide-to="2" class="slide-two"></li>
    </ol>
    <!-- 轮播（Carousel）项目 -->
    <div class="carousel-inner">
        <div class="item active">
            <img src="/static/images/banner_01.jpg" alt="First slide">
        </div>
        <div class="item">
            <img src="/static/images/banner_02.jpg" alt="First slide">
        </div>
        <div class="item">
            <img src="/static/images/banner_03.jpg" alt="First slide">
        </div>
    </div>
</div>
<div class="w1160">
    <div class="wItem" style="background: rgb(255,205,222);color: #a8063d;">
        <h1>自学考试</h1>
        <img src="/static/images/w1160_1.jpg" alt="" />
        <span style="padding-top: 18px;">
			<a href="javascript:void(0)" onclick="open_qq()" style="color: #a8063d;">名校汇聚于此</a><br />
			<a href="javascript:void(0)" onclick="open_qq()" style="color: #a8063d;">学历含金量高</a><br />
			<a href="javascript:void(0)" onclick="open_qq()" style="color: #a8063d;">学习周期灵活</a><br />
			<a href="javascript:void(0)" onclick="open_qq()" style="color: #a8063d;">全程费用极低</a><br />
			<a href="javascript:void(0)" onclick="open_qq()" style="color: #a8063d;">统招同等待遇</a><br />
			<a href="javascript:void(0)" onclick="open_qq()" style="color: #a8063d;">快速考取文凭</a>
		</span>
    </div>
    <div class="wItem" style="background: rgb(218,234,213);color: #308a14;">
        <h1>成人高考</h1>
        <img src="/static/images/w1160_2.jpg" alt="" />
        <span style="padding-top: 40px;">
			<a href="javascript:void(0)" onclick="open_qq()" style="color: #308a14;">考试零压力</a><br />
			<a href="javascript:void(0)" onclick="open_qq()" style="color: #308a14;">可脱产学习</a><br />
			<a href="javascript:void(0)" onclick="open_qq()" style="color: #308a14;">体验大学生活</a><br />
			<a href="javascript:void(0)" onclick="open_qq()" style="color: #308a14;">文凭国家承认</a>
		</span>
    </div>
    <div class="wItem" style="background: rgb(186,233,240);color: #02798b;">
        <h1>远程 函授 电大</h1>
        <img src="/static/images/w1160_3.jpg" alt="" />
        <span style="padding-top: 40px;">
			<a href="javascript:void(0)" onclick="open_qq()" style="color: #02798b;">时间地域无限制</a><br />
			<a href="javascript:void(0)" onclick="open_qq()" style="color: #02798b;">学习足不出沪</a><br />
			<a href="javascript:void(0)" onclick="open_qq()" style="color: #02798b;">优质教学资源</a><br />
			<a href="javascript:void(0)" onclick="open_qq()" style="color: #02798b;">网课实时更新</a>
		</span>
    </div>
    <div class="wItem" style="background: rgb(240,223,186);color: #845a01;">
        <h1>2017年报考指导书</h1>
        <img src="/static/images/w1160_4.jpg" alt="" />
        <span style="padding-top: 40px;">
			<a href="javascript:void(0)" onclick="open_qq()" style="color: #845a01;">嵩博2017版</a><br />
			<a href="javascript:void(0)" onclick="open_qq()" style="color: #845a01;">《成人学历报考指导白皮书》</a><br />
			<a href="javascript:void(0)" onclick="open_qq()" style="color: #845a01;">免费发放中，提醒考生</a><br />
			<a href="javascript:void(0)" onclick="open_qq()" style="color: #845a01;">切勿错过报考</a>
		</span>
    </div>
</div>
<style type="text/css">
    .w1160{
        width: 1160px;
        position: relative;
        left: 50%;
        margin-left: -580px;
        font-size: 0;
        letter-spacing: -5px;
        font-family: "微软雅黑";
        margin-top: 40px;
    }
    .wItem{
        display: inline-block;
        vertical-align: top;
        width: 230px;
        height: 310px;
        font-size: 16px;
        letter-spacing: normal;
        text-align: center;
        margin-left: 60px;
    }
    .wItem h1{
        padding: 9px 0;
    }
    .wItem span{
        display: inline-block;
    }
    .wItem img{
        width: 100%;
    }
    .wItem a{
        text-decoration: none;
    }
    .wItem a:hover{
        text-decoration: underline;
    }
</style>
<div class="w1">
    <div class="w1000">
        <div class="w1_btn">
            <span class="w1_b1"><a href="javascript:void(0);" onclick="open_qq()"></a></span>
            <span class="w1_b2"><a href="javascript:void(0);" onclick="open_qq()"></a></span>
            <span class="w1_b3"><a href="javascript:void(0);" onclick="open_qq()"></a></span>
        </div>
    </div>
</div>
<div class="w2">
    <div class="w1000">
        <div>
            <img src="/static/images/w2.jpg" alt=""/>
        </div>
        <div class="w2_shl">
            <div><a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/w2_1.jpg" alt=""/></a></div>
            <div><a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/w2_2.jpg" alt=""/></a></div>
            <div><a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/w2_3.jpg" alt=""/></a></div>
            <div><a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/w2_4.jpg" alt=""/></a></div>
            <div><a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/w2_5.jpg" alt=""/></a></div>
            <div><a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/w2_6.jpg" alt=""/></a></div>
            <div><a href="javascript:void(0);" onclick="open_qq()"><img src="/static/images/w2_7.jpg" alt=""/></a></div>

        </div>
    </div>
</div>
<div class="w3">
    <div class="w1000">
        <img src="/static/images/w3.jpg" alt=""/>
        <ul class="window">
            <li><a href="javascript:void(0);" onclick="open_qq()" class="ha h1"></a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()" class="ha h2"></a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()" class="ha h3"></a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()" class="ha h4"></a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()" class="ha h5"></a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()" class="ha h6"></a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()" class="ha h7"></a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()"  class="ha h8"></a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()"  class="ha h9"></a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()" class="ha h10"></a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()" class="ha h11"></a></li>
            <li><a href="javascript:void(0);" onclick="open_qq()" class="ha h12"></a></li>
        </ul>
        <div class="inputBox">
            <div class="inputTitle">
            </div>
            <div class="input">
                <form action="http://www.xsjedu.org/Orders/CoursesSave.asp" method="post" enctype="application/x-www-form-urlencoded" name="frm" id="frm"  onSubmit="return CheckForm();">
                    <p><input type="text" id="Orders_Name" name="Orders_Name" placeholder="您的姓名"/></p>

                    <p><input type="text" id="Orders_Tel" name="Orders_Tel" placeholder="您的联系电话"/></p>

                    <p><input type="text" name="Orders_Remarks" placeholder="咨询详情描述" class="describe"/></p>

                    <p><input type="submit" value="提交" class="submit" id="btn_submit">
                        <input type="hidden" name="City_id" value="47" />
                        <input type="hidden" name="Source_id" value="451" />
                        <input type="hidden" name="Language_id" value="40" /></p>
                </form>
            </div>
        </div>
    </div>
</div>
<div class="w4">
    <div class="w1000">
        <img src="/static/images/w4.jpg" alt=""/>
        <div class="btn_2"><span><a href="javascript:void(0);" onclick="open_qq()">了解快速拿名校本科</a></span></div>
    </div>
</div>
<div class="w5">
    <div class="w1000">
        <div class="w5_btn">
            <span class="w5_b1"><a href="javascript:void(0);" onclick="open_qq()"></a></span>
            <span class="w5_b2"><a href="javascript:void(0);" onclick="open_qq()"></a></span>
        </div>
    </div>
</div>
<div class="w6">
    <div class="w1000">
        <div class="w6_btn">
            <span class="w6_b1"><a href="javascript:void(0);" onclick="open_qq()"></a></span>
            <span class="w6_b2"><a href="javascript:void(0);" onclick="open_qq()"></a></span>
        </div>
    </div>
</div>
<div class="w7">
    <div class="w1000">
        <div class="w7_btn">
            <span class="w7_b1"><a href="javascript:void(0);" onclick="open_qq()"></a></span>
            <span class="w7_b2"><a href="javascript:void(0);" onclick="open_qq()"></a></span>
        </div>
    </div>
</div>
<div class="w8">
    <div class="w1000">
        <div class="w8_btn">
            <span class="w8_b1"><a href="javascript:void(0);" onclick="open_qq()"></a></span>
            <span class="w8_b2"><a href="javascript:void(0);" onclick="open_qq()"></a></span>
        </div>
    </div>
</div>
<div class="w9">
    <div class="w1000">
        <div class="w9_btn">
            <span class="w9_b1"><a href="javascript:void(0);" onclick="open_qq()"></a></span>
            <span class="w9_b2"><a href="javascript:void(0);" onclick="open_qq()"></a></span>
        </div>
    </div>
</div>
<div class="w10">
    <div class="w1000">
        <div class="w10_btn">
            <span class="w10_b1"><a href="javascript:void(0);" onclick="open_qq()"></a></span>
            <span class="w10_b2"><a href="javascript:void(0);" onclick="open_qq()"></a></span>
            <span class="w10_b3"><a href="javascript:void(0);" onclick="open_qq()"></a></span>
            <span class="w10_b4"><a href="javascript:void(0);" onclick="open_qq()"></a></span>
            <span class="w10_b5"><a href="javascript:void(0);" onclick="open_qq()"></a></span>
        </div>
    </div>
</div>
<div class="w12">
    <div class="w1004"></div>
    <div class="w1000">
        <div class="btn_2"><span><a href="javascript:void(0);" onclick="open_qq()">我要报读学历课程</a></span><span>TEL:17898837879</span></div>
    </div>
</div>
<div class="wrap wrap_02">
    <div class="contain foot">
        <div class="foot_code">
            <div><img src="/static/images/code_01.png"></div>
            <div><img src="/static/images/code_02.png"></div></div>
        <dl class="clearfix">

            <dd id="footHelp">
                <strong><i></i><a href="javascript:void(0);" onclick="open_qq()">客服中心</a></strong>
                <span class="clearfix"><a href="javascript:void(0);" onclick="open_qq()"><em>17898837879</em>（免长途费）</a></span>
                <span class="clearfix"><a href="javascript:void(0);" onclick="open_qq()"><div class="fIcon_01"></div>邮箱：Service@neworldonline.org</a></span>
                <span class="clearfix"><a href="http://weibo.com/neworldonline" target="_blank"><div class="fIcon_02"></div>新浪微博：weibo.com/neworldonline</a></span>
                <span class="clearfix"><a href="javascript:void(0);" onclick="open_qq()"><div class="fIcon_04"></div>在线客服（每日9:00-24:00）</a></span>
            </dd>
            <dd>
                <strong><a href="javascript:void(0);"onclick="open_qq()">关于课程</a></strong>
                <span><a href="javascript:void(0);" onclick="open_qq()">成人自考</a></span>
                <span><a href="javascript:void(0);" onclick="open_qq()">成人高考</a></span>
                <span><a href="javascript:void(0);" onclick="open_qq()">远程教育</a></span>
                <span><a href="javascript:void(0);" onclick="open_qq()">网络教育</a></span>
            </dd>
            <dd>
                <strong style="visibility: hidden" ><a href="javascript:void(0);" onclick="open_qq()">关于课程</a></strong>
                <span><a href="javascript:void(0);" onclick="open_qq()">日语培训</a></span>
                <span><a href="javascript:void(0);" onclick="open_qq()">英语培训</a></span>
                <span><a href="javascript:void(0);" onclick="open_qq()">法语培训</a></span>
                <span><a href="javascript:void(0);" onclick="open_qq()">德语培训</a></span>
            </dd>
            <dd>
                <strong><a href="#" target="_blank">嵩博集团</a></strong>
                <span><a href="#" target="_blank">关于我们</a></span>
                <span><a href="#" target="_blank">学校荣誉</a></span>
                <span><a href="#" target="_blank">联系我们</a></span>
                <span><a href="#" target="_blank">友情链接</a></span>
                <span><a href="#" target="_blank">招聘贤才</a></span>
            </dd>
        </dl>
    </div>
</div>
Copyright @2016 上海嵩博教育科技有限公司 版权所有All rights reserved 沪ICP备08018177号
<div id="doyoo_panel" class="doyoo_pan_icon" style="position: fixed; top: 150px; right: 5px; width: 125px; height: 356px;">
    <div class="doyoo_pan_icon_inner" id="looyu_dom_0" style="width: 125px; float: right; background-image: url(&quot;/static/images/zx1.png&quot;);">
        <a href="javascript:;" id="looyu_dom_1" style="display:block;width:100%;height:100%;">&nbsp;</a>
    </div>
</div>
<link rel="stylesheet" type="text/css" href="/static/css/oms.css">
<script>
    var title =document.getElementById("nav");
    window.onscroll = function(){
        var scrollTop = document.documentElement.scrollTop ||document.body.scrollTop;
        if(scrollTop>45){
            title.style.opacity="0.8";
        }else{
            title.style.opacity="1";
        }
    }
</script>
<script src="/static/js/jquery-2.1.1.min.js"></script>
<script src="/static/js/bootstrap.min.js"></script>
<script src="/static/js/common.js"></script>
<script src="/static/js/index.js"></script>
</body>
</html>
