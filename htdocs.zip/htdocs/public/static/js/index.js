$(function(){
    $('.carousel').carousel();
    $('.carousel-indicators li').each(function(_f){
        $(this).hover(function(){
            $("#banner").carousel(_f);
        })
    })
})