//navList
window.onscroll = function(){
    var scrollTop = document.documentElement.scrollTop ||document.body.scrollTop;
    var title =document.getElementById("nav");
    if(scrollTop>45){
        title.style.opacity="0.8";
    }else{
        title.style.opacity="1";
    }
};
$(document).ready(
    function(){
        $(".search").on("mouseover",function(){
            var d_height=$(".search").find("dl").eq(0).height();
            $(".search").find("dl").each(function(){
                $(this).css("height",d_height);
            });
        })

    }
);
